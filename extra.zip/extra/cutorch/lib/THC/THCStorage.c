#include "THCStorage.h"
#include "THCGeneral.h"
#include "THAtomic.h"

#include "THCHalf.h"

#include "generic/THCStorage.c"
#include "THCGenerateAllTypes.h"
